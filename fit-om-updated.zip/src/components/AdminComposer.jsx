const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useRef, useState } from "react";
import { FileVideo, ImagePlus, LoaderCircle, UploadCloud, X } from "lucide-react";

import { parseTags } from "@/lib/journey";

export default function AdminComposer({ editing, onDone, onCancelEdit }) {
  const [caption, setCaption] = useState("");
  const [tags, setTags] = useState("");
  const [file, setFile] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const inputRef = useRef(null);

  useEffect(() => {
    setCaption(editing?.caption ?? "");
    setTags((editing?.tags ?? []).join(", "));
    setFile(null);
    setError("");
  }, [editing]);

  async function submit(event) {
    event.preventDefault();
    setError("");
    if (!caption.trim()) {
      setError("A caption keeps the moment honest.");
      return;
    }
    setBusy(true);
    try {
      if (editing) {
        await db.entities.JourneyPost.update(editing.id, {
          caption: caption.trim(),
          tags: parseTags(tags),
        });
        onDone();
        return;
      }
      if (!file) {
        setError("Choose an image or video to publish.");
        return;
      }
      const { file_url } = await db.integrations.Core.UploadPublicFile({
        file,
      });
      await db.entities.JourneyPost.create({
        media_url: file_url,
        media_type: file.type.startsWith("video/") ? "video" : "image",
        caption: caption.trim(),
        tags: parseTags(tags),
      });

      setCaption("");
      setTags("");
      setFile(null);
      if (inputRef.current) inputRef.current.value = "";
      onDone();
    } catch (submissionError) {
      setError(
        submissionError instanceof Error
          ? submissionError.message
          : "Something went wrong. Try again."
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <form
      onSubmit={submit}
      className="border border-foreground/15 bg-card p-5 md:p-7"
    >
      <div className="mb-7 flex items-start justify-between">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-[.24em] text-accent">
            New entry / {editing ? "edit" : "publish"}
          </p>
          <h2 className="mt-2 font-display text-2xl font-bold">
            {editing ? "Tighten the record." : "Put the work on record."}
          </h2>
        </div>
        {editing && (
          <button
            type="button"
            onClick={onCancelEdit}
            className="rounded-full p-2 text-muted-foreground hover:bg-secondary hover:text-foreground"
            aria-label="Cancel editing"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>
      {!editing && (
        <div className="mb-5">
          <input
            ref={inputRef}
            type="file"
            accept="image/*,video/*"
            className="sr-only"
            onChange={(event) => setFile(event.target.files?.[0] ?? null)}
          />
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            className="flex min-h-36 w-full flex-col items-center justify-center border border-dashed border-foreground/25 bg-background px-5 text-center transition-colors hover:border-accent hover:bg-secondary"
          >
            {file ? (
              <>
                <div className="mb-2 flex items-center gap-2 font-semibold">
                  {file.type.startsWith("video/") ? (
                    <FileVideo className="h-5 w-5 text-accent" />
                  ) : (
                    <ImagePlus className="h-5 w-5 text-accent" />
                  )}
                  {file.name}
                </div>
                <span className="font-mono text-[10px] uppercase tracking-[.14em] text-muted-foreground">
                  Choose another file
                </span>
              </>
            ) : (
              <>
                <UploadCloud className="mb-3 h-7 w-7 text-accent" />
                <span className="font-semibold">Select the evidence</span>
                <span className="mt-1 font-mono text-[10px] uppercase tracking-[.14em] text-muted-foreground">
                  JPG, PNG, MP4 · one file at a time
                </span>
              </>
            )}
          </button>
        </div>
      )}
      <label className="block">
        <span className="mb-2 block font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">
          Caption
        </span>
        <textarea
          value={caption}
          onChange={(event) => setCaption(event.target.value)}
          maxLength={2000}
          rows={5}
          placeholder="What changed? What stayed difficult?"
          className="w-full resize-y border border-foreground/15 bg-background px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-accent"
        />
      </label>
      <label className="mt-4 block">
        <span className="mb-2 block font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">
          Tags · comma separated
        </span>
        <input
          value={tags}
          onChange={(event) => setTags(event.target.value)}
          placeholder="push day, pr, cut phase"
          className="w-full border border-foreground/15 bg-background px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-accent"
        />
      </label>
      {error && (
        <p className="mt-3 text-sm text-destructive" role="alert">
          {error}
        </p>
      )}
      <button
        type="submit"
        disabled={busy}
        className="mt-5 flex w-full items-center justify-center gap-2 bg-primary px-5 py-3 text-xs font-bold uppercase tracking-[.16em] text-primary-foreground transition-transform hover:-translate-y-0.5 disabled:cursor-wait disabled:opacity-60"
      >
        {busy ? (
          <>
            <LoaderCircle className="h-4 w-4 animate-spin" />{" "}
            {editing ? "Saving" : "Uploading"}
          </>
        ) : editing ? (
          "Save changes"
        ) : (
          "Publish to archive"
        )}
      </button>
    </form>
  );
}