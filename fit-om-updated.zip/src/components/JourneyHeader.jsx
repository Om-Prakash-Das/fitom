import { Link } from "react-router-dom";
import { ArrowUpRight, LogIn, Shield } from "lucide-react";
import { isAdminUnlocked, lockAdmin } from "@/lib/adminGate";

export default function JourneyHeader({ dark = false }) {
  const unlocked = isAdminUnlocked();
  const ink = dark ? "text-ink" : "text-foreground";

  return (
    <header
      className={`relative z-20 flex items-center justify-between px-5 py-5 md:px-10 ${ink}`}
    >
      <Link to="/" className="group flex items-center gap-3">
        <span className="flex h-9 w-9 items-center justify-center bg-primary text-[11px] font-bold tracking-[-.08em] text-primary-foreground transition-transform group-hover:rotate-6">
          A/01
        </span>
        <span className="font-display text-sm font-bold tracking-[.12em]">
          THE SETS ARCHIVE
        </span>
      </Link>
      <nav className="flex items-center gap-3 text-xs font-semibold uppercase tracking-[.16em]">
        <a
          href="/#archive"
          className="hidden transition-opacity hover:opacity-60 sm:inline"
        >
          Archive
        </a>
        <Link
          to="/workouts"
          className="hidden transition-opacity hover:opacity-60 sm:inline"
        >
          Log
        </Link>
        {unlocked ? (
          <>
            <Link
              to="/admin"
              className="flex items-center gap-2 border border-current/20 px-3 py-2 transition-colors hover:bg-primary hover:text-primary-foreground"
            >
              <Shield className="h-3.5 w-3.5" /> Portal
            </Link>
            <button
              type="button"
              onClick={() => {
                lockAdmin();
                window.location.href = "/";
              }}
              className="hidden px-2 py-2 opacity-60 transition-opacity hover:opacity-100 sm:inline"
            >
              Exit
            </button>
          </>
        ) : (
          <Link
            to="/login"
            className="flex items-center gap-2 border border-current/20 px-3 py-2 transition-colors hover:bg-primary hover:text-primary-foreground"
          >
            <LogIn className="h-3.5 w-3.5" /> Owner sign in{" "}
            <ArrowUpRight className="h-3 w-3" />
          </Link>
        )}
      </nav>
    </header>
  );
}