import { Copy, Pencil, Trash2 } from "lucide-react";
import { formatArchiveDate } from "@/lib/journey";

// Groups consecutive exercises sharing a truthy `group` value so supersets
// render together, the same way the composer builds them.
function buildBlocks(exercises) {
  const blocks = [];
  let i = 0;
  while (i < exercises.length) {
    const ex = exercises[i];
    if (ex.group) {
      const items = [];
      let j = i;
      while (j < exercises.length && exercises[j].group === ex.group) {
        items.push(exercises[j]);
        j++;
      }
      if (items.length > 1) {
        blocks.push({ type: "superset", groupId: ex.group, items });
        i = j;
        continue;
      }
    }
    blocks.push({ type: "single", ex });
    i += 1;
  }
  return blocks;
}

function groupLetters(blocks) {
  const map = {};
  let n = 0;
  for (const b of blocks) {
    if (b.type === "superset" && !(b.groupId in map)) {
      map[b.groupId] = String.fromCharCode(65 + n);
      n += 1;
    }
  }
  return map;
}

function ExerciseBlock({ ex }) {
  return (
    <div>
      <p className="font-display text-lg font-bold tracking-[-.02em]">{ex.name}</p>
      <ul className="mt-2 space-y-1.5">
        {ex.sets?.map((s, j) => (
          <li
            key={j}
            className="flex flex-wrap items-baseline gap-x-3 font-mono text-[11px] uppercase tracking-[.06em] text-muted-foreground"
          >
            <span className="font-bold text-foreground">Set {j + 1}</span>
            {s.detail && <span>{s.detail}</span>}
            {s.weight && <span className="text-accent">= {s.weight}</span>}
            {s.reps && <span>· {s.reps} reps</span>}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function WorkoutCard({ workout, admin, onEdit, onDelete, onRepeat }) {
  const dateLabel = workout.entry_date ? formatArchiveDate(workout.entry_date) : "Undated";
  const blocks = buildBlocks(workout.exercises || []);
  const letters = groupLetters(blocks);

  return (
    <article className="border border-foreground/10 bg-card p-5 md:p-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-[.18em] text-accent">
            {workout.day}
          </p>
          <h3 className="mt-1 font-display text-2xl font-bold leading-none tracking-[-.03em]">
            {dateLabel}
          </h3>
          {workout.focus && (
            <p className="mt-2 text-sm text-muted-foreground">
              Focus · {workout.focus}
            </p>
          )}
        </div>
        {admin && (
          <div className="flex shrink-0 gap-2">
            {onRepeat && (
              <button
                type="button"
                onClick={() => onRepeat(workout)}
                className="p-2 text-muted-foreground transition-colors hover:text-foreground"
                aria-label="Repeat this workout"
                title="Log a new session starting from this one"
              >
                <Copy className="h-4 w-4" />
              </button>
            )}
            <button
              type="button"
              onClick={() => onEdit(workout)}
              className="p-2 text-muted-foreground transition-colors hover:text-foreground"
              aria-label="Edit workout"
            >
              <Pencil className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => onDelete(workout)}
              className="p-2 text-muted-foreground transition-colors hover:text-destructive"
              aria-label="Delete workout"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        )}
      </div>

      <div className="mt-5 space-y-5">
        {blocks.map((block, i) =>
          block.type === "superset" ? (
            <div key={block.groupId} className="border-t border-foreground/10 pt-4">
              <div className="border border-accent/40 bg-accent/5 p-4">
                <p className="mb-3 font-mono text-[10px] uppercase tracking-[.16em] text-accent">
                  Superset {letters[block.groupId]}
                </p>
                <div className="space-y-4">
                  {block.items.map((ex, k) => (
                    <div key={k} className="border-l-2 border-accent/50 pl-3">
                      <ExerciseBlock ex={ex} />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div key={i} className="border-t border-foreground/10 pt-4">
              <ExerciseBlock ex={block.ex} />
            </div>
          )
        )}
      </div>

      {workout.notes && (
        <p className="mt-5 border-t border-foreground/10 pt-4 text-sm leading-relaxed text-muted-foreground">
          {workout.notes}
        </p>
      )}
    </article>
  );
}
