import { Link } from "react-router-dom";
import { ArrowUpRight, Play } from "lucide-react";
import { formatArchiveTime, postDate } from "@/lib/journey";

export default function PostCard({
  post,
  index,
  admin = false,
  onEdit,
  onDelete,
}) {
  const src = post.media_url;

  return (
    <article
      className={`group reveal relative overflow-hidden border border-foreground/10 bg-card transition-transform duration-500 hover:-translate-y-1 ${
        index % 5 === 1 ? "md:translate-y-8" : ""
      }`}
    >
      <span className="absolute left-0 top-0 z-10 h-0.5 w-0 bg-accent transition-all duration-500 group-hover:w-full" />
      <div className="relative aspect-[4/5] overflow-hidden bg-secondary">
        {src ? (
          post.media_type === "video" ? (
            <video
              className="h-full w-full object-cover grayscale transition duration-700 group-hover:scale-105 group-hover:grayscale-0"
              src={src}
              controls
              preload="metadata"
              aria-label={`Training video from ${formatArchiveTime(
                postDate(post)
              )}`}
            />
          ) : (
            <img
              className="h-full w-full object-cover grayscale transition duration-700 group-hover:scale-105 group-hover:grayscale-0"
              src={src}
              alt={post.caption || "Training archive image"}
              loading={index < 3 ? "eager" : "lazy"}
            />
          )
        ) : (
          <div className="h-full w-full animate-pulse bg-secondary" />
        )}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-foreground/65 via-transparent to-transparent opacity-60" />
        <div className="absolute left-4 top-4 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.18em] text-card">
          <span className="bg-foreground px-2 py-1">
            {String(index + 1).padStart(2, "0")}
          </span>
          {post.media_type === "video" && (
            <span className="flex items-center gap-1 bg-accent px-2 py-1 text-accent-foreground">
              <Play className="h-3 w-3 fill-current" /> Motion
            </span>
          )}
        </div>
        <time
          className="absolute bottom-4 left-4 font-mono text-[10px] uppercase tracking-[.14em] text-card"
          dateTime={postDate(post)}
        >
          {formatArchiveTime(postDate(post))}
        </time>
        {!admin && (
          <ArrowUpRight className="absolute bottom-4 right-4 h-5 w-5 text-card opacity-0 transition-opacity group-hover:opacity-100" />
        )}
      </div>
      <div className="flex min-h-[128px] flex-col justify-between gap-5 p-5">
        <div>
          <p className="text-[15px] leading-relaxed text-foreground">
            {post.caption}
          </p>
          {post.tags?.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-1.5">
              {post.tags.map((tag) => (
                <span
                  key={tag}
                  className="border border-foreground/15 px-2 py-0.5 font-mono text-[10px] uppercase tracking-[.12em] text-muted-foreground"
                >
                  #{tag}
                </span>
              ))}
            </div>
          )}
          {!admin && (
            <Link
              to={`/entry/${post.id}`}
              className="mt-4 inline-block font-mono text-[10px] uppercase tracking-[.16em] text-accent hover:underline"
            >
              Open entry →
            </Link>
          )}
        </div>
        {admin && (
          <div className="flex gap-2 border-t border-foreground/10 pt-4">
            <button
              type="button"
              onClick={() => onEdit?.(post)}
              className="text-xs font-semibold uppercase tracking-[.14em] text-muted-foreground transition-colors hover:text-foreground"
            >
              Edit
            </button>
            <button
              type="button"
              onClick={() => onDelete?.(post)}
              className="ml-auto text-xs font-semibold uppercase tracking-[.14em] text-destructive transition-colors hover:underline"
            >
              Remove
            </button>
          </div>
        )}
      </div>
    </article>
  );
}