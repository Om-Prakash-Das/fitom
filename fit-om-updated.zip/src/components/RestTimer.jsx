import { useEffect, useRef, useState } from "react";
import { Pause, Play, RotateCcw, Timer } from "lucide-react";

const PRESETS = [30, 60, 90, 120, 180];

function beep() {
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    const ctx = new Ctx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = 880;
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.5);
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.5);
  } catch {
    /* audio not available — fail silently */
  }
}

// A lightweight, ephemeral rest-timer used while logging a session.
// It holds no data of its own; nothing here is persisted with the workout.
export default function RestTimer() {
  const [duration, setDuration] = useState(90);
  const [remaining, setRemaining] = useState(null); // null = idle
  const [running, setRunning] = useState(false);
  const intervalRef = useRef(null);

  useEffect(() => {
    if (!running) return undefined;
    intervalRef.current = setInterval(() => {
      setRemaining((r) => {
        if (r === null) return null;
        if (r <= 1) {
          clearInterval(intervalRef.current);
          setRunning(false);
          beep();
          if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
          return 0;
        }
        return r - 1;
      });
    }, 1000);
    return () => clearInterval(intervalRef.current);
  }, [running]);

  function start(secs) {
    setDuration(secs);
    setRemaining(secs);
    setRunning(true);
  }

  function toggle() {
    if (remaining === null) {
      start(duration);
      return;
    }
    setRunning((r) => !r);
  }

  function reset() {
    clearInterval(intervalRef.current);
    setRunning(false);
    setRemaining(null);
  }

  const done = remaining === 0;
  const mm = remaining !== null ? String(Math.floor(remaining / 60)).padStart(2, "0") : null;
  const ss = remaining !== null ? String(remaining % 60).padStart(2, "0") : null;

  return (
    <div
      className={`flex flex-wrap items-center gap-3 border p-3 transition-colors ${
        done ? "border-accent bg-accent/10" : "border-foreground/15 bg-background/40"
      }`}
    >
      <Timer className="h-4 w-4 shrink-0 text-accent" />
      <div className="flex flex-wrap items-center gap-1.5">
        {PRESETS.map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => start(s)}
            className={`px-2.5 py-1.5 font-mono text-[10px] uppercase tracking-[.1em] transition-colors ${
              remaining !== null && duration === s
                ? "bg-primary text-primary-foreground"
                : "border border-foreground/15 hover:bg-secondary"
            }`}
          >
            {s < 60 ? `${s}s` : `${s / 60}m`}
          </button>
        ))}
      </div>

      <div className="ml-auto flex items-center gap-2">
        {remaining !== null && (
          <span className={`font-mono text-lg font-bold tabular-nums ${done ? "text-accent" : ""}`}>
            {mm}:{ss}
          </span>
        )}
        <button
          type="button"
          onClick={toggle}
          className="p-2 text-muted-foreground transition-colors hover:text-foreground"
          aria-label={running ? "Pause rest timer" : "Start rest timer"}
        >
          {running ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
        </button>
        {remaining !== null && (
          <button
            type="button"
            onClick={reset}
            className="p-2 text-muted-foreground transition-colors hover:text-foreground"
            aria-label="Reset rest timer"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        )}
      </div>
    </div>
  );
}
