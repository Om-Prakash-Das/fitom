export default function ArchiveSkeletons() {
  return (
    <div
      className="grid grid-cols-1 gap-5 md:grid-cols-3"
      aria-label="Loading archive"
    >
      {[1, 2, 3].map((item) => (
        <div
          key={item}
          className="animate-pulse border border-foreground/10 bg-card p-3"
        >
          <div className="aspect-[4/5] bg-secondary" />
          <div className="mt-4 h-3 w-4/5 bg-secondary" />
          <div className="mt-2 h-3 w-2/5 bg-secondary" />
        </div>
      ))}
    </div>
  );
}