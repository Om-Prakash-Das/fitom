import { Navigate, Outlet } from "react-router-dom";
import { isAdminUnlocked } from "@/lib/adminGate";

export default function AdminGate({ unauthenticatedElement }) {
  if (!isAdminUnlocked()) {
    return unauthenticatedElement || <Navigate to="/login" replace />;
  }
  return <Outlet />;
}