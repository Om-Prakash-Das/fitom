const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { Link2, Loader2, Plus, Sparkles, Trash2, Unlink } from "lucide-react";
import { formatArchiveDate } from "@/lib/journey";
import RestTimer from "@/components/RestTimer";

const WEEKDAYS = [
  "Monday", "Tuesday", "Wednesday", "Thursday",
  "Friday", "Saturday", "Sunday",
];

const EXERCISE_SUGGESTIONS_ID = "exercise-suggestions";

function weekdayOf(dateStr) {
  if (!dateStr) return WEEKDAYS[0];
  const d = new Date(`${dateStr}T12:00:00.000Z`);
  return WEEKDAYS[(d.getUTCDay() + 6) % 7];
}

function emptyExercise(group = null) {
  return { name: "", group, sets: [{ detail: "", weight: "", reps: "" }] };
}

function setsAreEmpty(sets) {
  return !sets?.length || sets.every((s) => !s.detail && !s.weight && !s.reps);
}

function summarizeSets(sets) {
  return (sets || [])
    .filter((s) => s.detail || s.weight || s.reps)
    .map((s) => {
      const wxr = [s.weight, s.reps ? `${s.reps} reps` : ""].filter(Boolean).join(" × ");
      return wxr || s.detail;
    })
    .join(", ");
}

// Groups a flat exercise list into render "blocks": consecutive exercises
// sharing a truthy `group` value become one superset block; everything else
// renders as a standalone exercise.
function buildBlocks(exercises) {
  const blocks = [];
  let i = 0;
  while (i < exercises.length) {
    const ex = exercises[i];
    if (ex.group) {
      const items = [];
      let j = i;
      while (j < exercises.length && exercises[j].group === ex.group) {
        items.push({ ex: exercises[j], index: j });
        j++;
      }
      if (items.length > 1) {
        blocks.push({ type: "superset", groupId: ex.group, items });
        i = j;
        continue;
      }
    }
    blocks.push({ type: "single", ex, index: i });
    i += 1;
  }
  return blocks;
}

function groupLetters(blocks) {
  const map = {};
  let n = 0;
  for (const b of blocks) {
    if (b.type === "superset" && !(b.groupId in map)) {
      map[b.groupId] = String.fromCharCode(65 + n);
      n += 1;
    }
  }
  return map;
}

const inputCls =
  "w-full border border-foreground/15 bg-background px-3 py-2.5 text-sm outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-accent";

export default function WorkoutComposer({
  editing,
  onDone,
  onCancel,
  exerciseNames = [],
  exerciseHistory = new Map(),
}) {
  const today = new Date().toISOString().slice(0, 10);
  const [date, setDate] = useState(
    editing?.entry_date ? editing.entry_date.slice(0, 10) : today
  );
  const [day, setDay] = useState(
    editing?.day || weekdayOf(editing?.entry_date?.slice(0, 10) || today)
  );
  const [focus, setFocus] = useState(editing?.focus || "");
  const [exercises, setExercises] = useState(
    editing?.exercises?.length
      ? editing.exercises.map((x) => ({ group: null, ...x }))
      : [emptyExercise()]
  );
  const [notes, setNotes] = useState(editing?.notes || "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  function setExercise(i, name) {
    setExercises((xs) => xs.map((x, idx) => (idx === i ? { ...x, name } : x)));
  }
  function setSet(i, j, field, val) {
    setExercises((xs) =>
      xs.map((x, idx) =>
        idx === i
          ? { ...x, sets: x.sets.map((s, jdx) => (jdx === j ? { ...s, [field]: val } : s)) }
          : x
      )
    );
  }
  function addSet(i) {
    setExercises((xs) =>
      xs.map((x, idx) =>
        idx === i ? { ...x, sets: [...x.sets, { detail: "", weight: "", reps: "" }] } : x
      )
    );
  }
  function removeSet(i, j) {
    setExercises((xs) =>
      xs.map((x, idx) =>
        idx === i ? { ...x, sets: x.sets.filter((_, jdx) => jdx !== j) } : x
      )
    );
  }
  function addExercise() {
    setExercises((xs) => [...xs, emptyExercise()]);
  }
  function removeExercise(i) {
    setExercises((xs) => xs.filter((_, idx) => idx !== i));
  }
  function prefillFromLast(i, entry) {
    setExercises((xs) =>
      xs.map((x, idx) =>
        idx === i
          ? { ...x, name: x.name || entry.name, sets: entry.sets.map((s) => ({ ...s })) }
          : x
      )
    );
  }
  function addSupersetPartner(i) {
    setExercises((xs) => {
      const cur = xs[i];
      const groupId = cur.group || `sup-${Date.now()}`;
      const updated = xs.map((x, idx) => (idx === i ? { ...x, group: groupId } : x));
      const partner = emptyExercise(groupId);
      return [...updated.slice(0, i + 1), partner, ...updated.slice(i + 1)];
    });
  }
  function unlinkFromSuperset(i) {
    setExercises((xs) => xs.map((x, idx) => (idx === i ? { ...x, group: null } : x)));
  }

  async function submit(e) {
    e.preventDefault();
    const trimmed = exercises
      .map((x) => ({
        name: x.name.trim(),
        group: x.group || null,
        sets: x.sets
          .map((s) => ({
            detail: s.detail.trim(),
            weight: s.weight.trim(),
            reps: s.reps.trim(),
          }))
          .filter((s) => s.detail || s.weight || s.reps),
      }))
      .filter((x) => x.name || x.sets.length);
    // Drop a group tag left dangling because its partner was removed.
    const groupCounts = {};
    for (const x of trimmed) if (x.group) groupCounts[x.group] = (groupCounts[x.group] || 0) + 1;
    const clean = trimmed.map((x) => (x.group && groupCounts[x.group] < 2 ? { ...x, group: null } : x));
    if (!clean.length) {
      setError("Add at least one exercise with a set.");
      return;
    }
    setSaving(true);
    setError("");
    const payload = {
      entry_date: `${date}T12:00:00.000Z`,
      day,
      focus: focus.trim(),
      exercises: clean,
      notes: notes.trim(),
    };
    try {
      if (editing?.id) {
        await db.entities.Workout.update(editing.id, payload);
      } else {
        await db.entities.Workout.create(payload);
      }
      onDone();
    } catch (err) {
      setError(err?.message || "Could not save the workout.");
    } finally {
      setSaving(false);
    }
  }

  const blocks = buildBlocks(exercises);
  const letters = groupLetters(blocks);

  function renderExercise(ex, i, { inSuperset = false } = {}) {
    const key = ex.name.trim().toLowerCase();
    const lastEntry = key ? exerciseHistory.get(key) : null;
    const showPrefillHint = lastEntry && setsAreEmpty(ex.sets);

    return (
      <div
        key={i}
        className={
          inSuperset
            ? "border-l-2 border-accent/50 pl-3"
            : "border border-foreground/10 bg-background/40 p-4"
        }
      >
        <div className="flex items-center gap-2">
          <input
            type="text"
            list={EXERCISE_SUGGESTIONS_ID}
            value={ex.name}
            onChange={(e) => setExercise(i, e.target.value)}
            placeholder="Exercise name — e.g. Flat bench press"
            className={`${inputCls} font-display font-bold`}
          />
          {inSuperset ? (
            <button
              type="button"
              onClick={() => unlinkFromSuperset(i)}
              className="shrink-0 p-2 text-muted-foreground hover:text-foreground"
              aria-label="Remove from superset"
              title="Unlink from superset"
            >
              <Unlink className="h-4 w-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={() => addSupersetPartner(i)}
              className="shrink-0 p-2 text-muted-foreground hover:text-accent"
              aria-label="Pair as superset"
              title="Superset with a new exercise"
            >
              <Link2 className="h-4 w-4" />
            </button>
          )}
          {exercises.length > 1 && (
            <button
              type="button"
              onClick={() => removeExercise(i)}
              className="shrink-0 p-2 text-muted-foreground hover:text-destructive"
              aria-label="Remove exercise"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          )}
        </div>

        {showPrefillHint && (
          <button
            type="button"
            onClick={() => prefillFromLast(i, lastEntry)}
            className="mt-2 flex items-center gap-1.5 text-left font-mono text-[10px] uppercase tracking-[.08em] text-muted-foreground hover:text-accent"
          >
            <Sparkles className="h-3 w-3 shrink-0" />
            Last time ({formatArchiveDate(lastEntry.date)}): {summarizeSets(lastEntry.sets)} — use these
          </button>
        )}

        <div className="mt-3 space-y-2">
          {ex.sets.map((s, j) => (
            <div key={j} className="grid grid-cols-12 items-center gap-2">
              <span className="col-span-2 font-mono text-[10px] uppercase tracking-[.14em] text-muted-foreground sm:col-span-1">Set {j + 1}</span>
              <input type="text" value={s.detail} onChange={(e) => setSet(i, j, "detail", e.target.value)} placeholder="10kg+10kg+20kg bar" className={`${inputCls} col-span-10 sm:col-span-6`} />
              <input type="text" value={s.weight} onChange={(e) => setSet(i, j, "weight", e.target.value)} placeholder="= 40kg" className={`${inputCls} col-span-6 sm:col-span-2`} />
              <input type="text" value={s.reps} onChange={(e) => setSet(i, j, "reps", e.target.value)} placeholder="12 reps" className={`${inputCls} col-span-5 sm:col-span-2`} />
              <button type="button" onClick={() => removeSet(i, j)} className="col-span-1 p-1 text-muted-foreground hover:text-destructive" aria-label="Remove set">
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>
        <button type="button" onClick={() => addSet(i)} className="mt-3 flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[.14em] text-accent hover:opacity-80">
          <Plus className="h-3.5 w-3.5" /> Add set
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-6">
      <datalist id={EXERCISE_SUGGESTIONS_ID}>
        {exerciseNames.map((n) => (
          <option key={n} value={n} />
        ))}
      </datalist>

      <RestTimer />

      <div className="grid gap-4 sm:grid-cols-3">
        <label className="block">
          <span className="mb-2 block font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">Date</span>
          <input type="date" value={date} onChange={(e) => { setDate(e.target.value); setDay(weekdayOf(e.target.value)); }} className={inputCls} required />
        </label>
        <label className="block">
          <span className="mb-2 block font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">Day</span>
          <select value={day} onChange={(e) => setDay(e.target.value)} className={inputCls}>
            {WEEKDAYS.map((w) => <option key={w} value={w}>{w}</option>)}
          </select>
        </label>
        <label className="block">
          <span className="mb-2 block font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">Focus</span>
          <input type="text" value={focus} onChange={(e) => setFocus(e.target.value)} placeholder="e.g. Chest" className={inputCls} />
        </label>
      </div>

      <div className="space-y-5">
        {blocks.map((block) =>
          block.type === "superset" ? (
            <div key={block.groupId} className="border border-accent/40 bg-accent/5 p-4">
              <p className="mb-3 font-mono text-[10px] uppercase tracking-[.18em] text-accent">
                Superset {letters[block.groupId]}
              </p>
              <div className="space-y-4">
                {block.items.map(({ ex, index }) => renderExercise(ex, index, { inSuperset: true }))}
              </div>
            </div>
          ) : (
            renderExercise(block.ex, block.index)
          )
        )}
      </div>

      <button type="button" onClick={addExercise} className="flex items-center gap-2 border border-foreground/20 px-4 py-2.5 font-mono text-[10px] uppercase tracking-[.14em] hover:bg-secondary">
        <Plus className="h-4 w-4" /> Add exercise
      </button>

      <label className="block">
        <span className="mb-2 block font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">Notes</span>
        <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} placeholder="How the session felt, PRs, what to change…" className={`${inputCls} resize-none`} />
      </label>

      {error && <p className="border border-destructive/40 bg-destructive/10 px-3 py-2 font-mono text-[11px] uppercase tracking-[.12em] text-destructive">{error}</p>}

      <div className="flex items-center gap-3">
        <button type="submit" disabled={saving} className="flex items-center gap-2 bg-primary px-6 py-3 text-xs font-bold uppercase tracking-[.16em] text-primary-foreground transition-transform hover:-translate-y-0.5 disabled:opacity-60">
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : null} {editing?.id ? "Save changes" : "Log this workout"}
        </button>
        <button type="button" onClick={onCancel} className="px-4 py-3 font-mono text-[10px] uppercase tracking-[.14em] text-muted-foreground hover:text-foreground">
          Cancel
        </button>
      </div>
    </form>
  );
}
