import { useEffect, useRef, useState } from "react";
import { CheckCircle2, Images, Loader2, X } from "lucide-react";
import { startPhotosPicker } from "@/functions/startPhotosPicker";
import { photosSessionStatus } from "@/functions/photosSessionStatus";
import { importPhotosFromSession } from "@/functions/importPhotosFromSession";

const POLL_MS = 4000;
const MAX_POLL_MS = 10 * 60 * 1000;

export default function PhotosImporter({ onImported }) {
  const [state, setState] = useState("idle"); // idle | starting | waiting | importing | done | error
  const [message, setMessage] = useState("");
  const [result, setResult] = useState(null);
  const sessionIdRef = useRef(null);
  const pollRef = useRef(null);
  const startedAtRef = useRef(0);

  useEffect(() => () => stopPolling(), []);

  function stopPolling() {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
  }

  async function start() {
    setState("starting");
    setMessage("Opening Google Photos picker…");
    setResult(null);
    try {
      const res = await startPhotosPicker({});
      const { pickerUri, sessionId } = res.data || res;
      sessionIdRef.current = sessionId;
      window.open(pickerUri, "_blank", "noopener");
      setState("waiting");
      setMessage("Select your photos in the picker, then click Done there.");
      startedAtRef.current = Date.now();
      stopPolling();
      pollRef.current = setInterval(poll, POLL_MS);
    } catch (e) {
      setState("error");
      setMessage(e?.message || "Could not start the picker.");
    }
  }

  async function poll() {
    if (!sessionIdRef.current) return;
    if (Date.now() - startedAtRef.current > MAX_POLL_MS) {
      stopPolling();
      setState("error");
      setMessage("The picker timed out. Try again.");
      return;
    }
    try {
      const res = await photosSessionStatus({ sessionId: sessionIdRef.current });
      const { mediaItemsSet } = res.data || res;
      if (mediaItemsSet) {
        stopPolling();
        runImport();
      }
    } catch {
      // transient polling errors are ignored
    }
  }

  async function runImport() {
    setState("importing");
    setMessage("Pulling your photos and writing captions…");
    try {
      const res = await importPhotosFromSession({
        sessionId: sessionIdRef.current,
      });
      const data = res.data || res;
      setState("done");
      setResult(data);
      setMessage(
        `Imported ${data.imported || 0} ${
          data.imported === 1 ? "entry" : "entries"
        }${data.skipped ? ` · ${data.skipped} skipped` : ""}.`
      );
      if (onImported) onImported();
    } catch (e) {
      setState("error");
      setMessage(e?.message || "Import failed.");
    }
  }

  function reset() {
    stopPolling();
    sessionIdRef.current = null;
    setState("idle");
    setMessage("");
    setResult(null);
  }

  return (
    <section className="mb-10 border border-foreground/15 bg-card p-5 md:p-7">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-[.24em] text-accent">
            Import / Google Photos
          </p>
          <h2 className="mt-2 font-display text-2xl font-bold">
            Pull from Google Photos.
          </h2>
          <p className="mt-2 max-w-md text-sm text-muted-foreground">
            Open the picker, choose the sets to put on record. Each photo&rsquo;s
            date, camera and file details are read straight from its metadata,
            with captions and tags written for you.
          </p>
        </div>
        {state !== "idle" && (
          <button
            type="button"
            onClick={reset}
            className="rounded-full p-2 text-muted-foreground hover:bg-secondary hover:text-foreground"
            aria-label="Dismiss"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      <div className="mt-5">
        {state === "idle" && (
          <button
            type="button"
            onClick={start}
            className="flex items-center gap-2 bg-primary px-5 py-3 text-xs font-bold uppercase tracking-[.16em] text-primary-foreground transition-transform hover:-translate-y-0.5"
          >
            <Images className="h-4 w-4" /> Open Google Photos picker
          </button>
        )}

        {state !== "idle" && (
          <div className="flex items-center gap-3 text-sm">
            {state === "done" ? (
              <CheckCircle2 className="h-5 w-5 text-primary" />
            ) : (
              <Loader2 className="h-5 w-5 animate-spin text-accent" />
            )}
            <span
              className={state === "error" ? "text-destructive" : "text-foreground"}
            >
              {message}
            </span>
          </div>
        )}

        {state === "waiting" && (
          <button
            type="button"
            onClick={runImport}
            className="mt-4 flex items-center gap-2 border border-foreground/20 px-4 py-2.5 text-xs font-bold uppercase tracking-[.14em] hover:bg-secondary"
          >
            I&rsquo;ve finished selecting — import now
          </button>
        )}
      </div>
    </section>
  );
}