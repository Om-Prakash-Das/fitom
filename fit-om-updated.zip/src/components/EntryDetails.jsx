import { CalendarDays, Aperture, Image as ImageIcon, MapPin } from "lucide-react";
import { postDate } from "@/lib/journey";

function Row({ icon: Icon, title, subtitle }) {
  return (
    <div className="flex items-start gap-4 py-4 first:pt-0 last:pb-0">
      <Icon className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
      <div className="min-w-0">
        {title && (
          <p className="break-words font-display text-base font-bold leading-tight tracking-[-.02em] text-foreground">
            {title}
          </p>
        )}
        {subtitle && (
          <p className="mt-1 font-mono text-[10px] uppercase tracking-[.14em] text-muted-foreground">
            {subtitle}
          </p>
        )}
      </div>
    </div>
  );
}

function formatCoord(value, posLabel, negLabel) {
  return `${Math.abs(value).toFixed(4)}° ${value >= 0 ? posLabel : negLabel}`;
}

export default function EntryDetails({ post }) {
  const meta = post?.photo_metadata || {};
  const date = postDate(post);
  const hasCamera = meta.camera || meta.exposure;
  const hasFile = meta.filename || meta.resolution;
  const hasLocation =
    meta.location && meta.location.lat != null && meta.location.lon != null;
  if (!date && !hasCamera && !hasFile && !hasLocation) return null;

  const dateObj = date ? new Date(date) : null;
  const dateLabel = dateObj
    ? new Intl.DateTimeFormat("en-US", {
        month: "short",
        day: "2-digit",
        year: "numeric",
      }).format(dateObj)
    : "";
  const timeLabel = dateObj
    ? new Intl.DateTimeFormat("en-US", {
        weekday: "short",
        hour: "numeric",
        minute: "2-digit",
        timeZoneName: "short",
      }).format(dateObj)
    : "";

  const coords = hasLocation
    ? `${formatCoord(meta.location.lat, "N", "S")}, ${formatCoord(
        meta.location.lon,
        "E",
        "W"
      )}`
    : "";
  const mapUrl = hasLocation
    ? `https://www.google.com/maps/search/?api=1&query=${meta.location.lat},${meta.location.lon}`
    : "";

  return (
    <div className="mt-8 divide-y divide-foreground/10 border-y border-foreground/10">
      {date && <Row icon={CalendarDays} title={dateLabel} subtitle={timeLabel} />}
      {hasCamera && <Row icon={Aperture} title={meta.camera} subtitle={meta.exposure} />}
      {hasFile && <Row icon={ImageIcon} title={meta.filename} subtitle={meta.resolution} />}
      {hasLocation && (
        <a
          href={mapUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-start gap-4 py-4 transition-opacity hover:opacity-80 last:pb-0"
        >
          <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
          <div className="min-w-0">
            <p className="break-words font-display text-base font-bold leading-tight tracking-[-.02em] text-foreground">
              {coords}
            </p>
            <p className="mt-1 font-mono text-[10px] uppercase tracking-[.14em] text-accent">
              View on map ↗
            </p>
          </div>
        </a>
      )}
    </div>
  );
}