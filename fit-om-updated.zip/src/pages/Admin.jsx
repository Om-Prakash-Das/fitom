const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useMemo, useState } from "react";
import { Download, LogOut, ShieldAlert, Sparkles } from "lucide-react";
import JourneyHeader from "@/components/JourneyHeader";
import PostCard from "@/components/PostCard";
import AdminComposer from "@/components/AdminComposer";
import ArchiveSkeletons from "@/components/ArchiveSkeletons";
import { listPosts, statsFromPosts } from "@/lib/journey";
import PhotosImporter from "@/components/PhotosImporter";

import { lockAdmin } from "@/lib/adminGate";

export default function Admin() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [notice, setNotice] = useState("");

  async function refresh() {
    setLoading(true);
    try {
      const data = await listPosts();
      setPosts(data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  const stats = useMemo(() => statsFromPosts(posts), [posts]);

  async function remove(post) {
    if (!window.confirm("Remove this entry from the archive?")) return;
    setNotice("");
    try {
      await db.entities.JourneyPost.delete(post.id);
      await refresh();
      setNotice("Entry removed from the record.");
    } catch {
      setNotice("Could not remove that entry. Try again.");
    }
  }

  function exportArchive() {
    const payload = {
      exported_at: new Date().toISOString(),
      note: "Media URLs are public links to the stored files.",
      entries: posts,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: "application/json",
    });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `sets-archive-backup-${new Date()
      .toISOString()
      .slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  return (
    <main className="film-grain min-h-[100dvh] bg-background">
      <JourneyHeader />
      <div className="mx-auto max-w-6xl px-5 py-12 md:px-10">
        <div className="flex flex-col justify-between gap-5 border-b border-foreground/15 pb-6 md:flex-row md:items-end">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[.24em] text-accent">
              Owner portal
            </p>
            <h1 className="mt-3 font-display text-4xl font-bold tracking-[-.06em] md:text-6xl">
              Keep the record.
            </h1>
            <p className="mt-3 text-sm text-muted-foreground">
              Signed in as owner. Publish, edit and remove
              entries from The Sets Archive.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={exportArchive}
              disabled={!posts.length}
              className="flex items-center gap-2 border border-foreground/20 px-4 py-3 text-xs font-bold uppercase tracking-[.14em] transition-colors hover:bg-secondary disabled:opacity-40"
            >
              <Download className="h-4 w-4" /> Export
            </button>
            <button
              type="button"
              onClick={() => {
                lockAdmin();
                window.location.href = "/";
              }}
              className="flex items-center gap-2 border border-foreground/20 px-4 py-3 text-xs font-bold uppercase tracking-[.14em] transition-colors hover:bg-secondary"
            >
              <LogOut className="h-4 w-4" /> Exit
            </button>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-2 gap-px overflow-hidden border border-foreground/10 bg-foreground/10 md:grid-cols-4">
          {[
            { label: "Entries", value: stats.postCount },
            { label: "Images", value: stats.imageCount },
            { label: "Videos", value: stats.videoCount },
            { label: "Owner", value: "A/01" },
          ].map((s) => (
            <div key={s.label} className="bg-card p-5">
              <p className="font-display text-3xl font-bold leading-none">
                {s.value}
              </p>
              <p className="mt-2 font-mono text-[10px] uppercase tracking-[.16em] text-muted-foreground">
                {s.label}
              </p>
            </div>
          ))}
        </div>

        {notice && (
          <div className="mt-6 flex items-center gap-2 border border-primary/40 bg-primary/10 px-4 py-3 text-sm">
            <Sparkles className="h-4 w-4 text-accent" /> {notice}
          </div>
        )}

        <PhotosImporter onImported={refresh} />

        <div className="mt-10 grid gap-10 md:grid-cols-[.85fr_1.15fr]">
          <AdminComposer
            editing={editing}
            onDone={() => {
              setEditing(null);
              setNotice("");
              refresh();
            }}
            onCancelEdit={() => setEditing(null)}
          />

          <div>
            <div className="mb-5 flex items-center gap-2">
              <ShieldAlert className="h-4 w-4 text-accent" />
              <h2 className="font-display text-xl font-bold">
                On the record ({posts.length})
              </h2>
            </div>
            {loading ? (
              <ArchiveSkeletons />
            ) : posts.length === 0 ? (
              <div className="border border-dashed border-foreground/20 bg-card p-12 text-center text-sm text-muted-foreground">
                Nothing published yet. Put the first set on record.
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                {posts.map((post, index) => (
                  <PostCard
                    key={post.id}
                    post={post}
                    index={index}
                    admin
                    onEdit={(p) => {
                      setEditing(p);
                      setNotice("");
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                    onDelete={remove}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}