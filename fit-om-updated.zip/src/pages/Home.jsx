import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowDown,
  CalendarDays,
  Camera,
  Film,
  MoveDown,
  Quote,
  Ruler,
} from "lucide-react";
import JourneyHeader from "@/components/JourneyHeader";
import PostCard from "@/components/PostCard";
import ArchiveSkeletons from "@/components/ArchiveSkeletons";
import {
  formatArchiveDate,
  listPosts,
  postDate,
  statsFromPosts,
} from "@/lib/journey";

function FilterChip({ active, onClick, children }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`border px-3 py-1.5 font-mono text-[10px] uppercase tracking-[.14em] transition-colors ${
        active
          ? "border-foreground bg-foreground text-card"
          : "border-foreground/20 text-muted-foreground hover:border-foreground hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );
}

function Stat({ icon: Icon, label, value }) {
  return (
    <div className="bg-primary p-5">
      <Icon className="h-5 w-5" />
      <p className="mt-4 font-display text-3xl font-bold leading-none">
        {value}
      </p>
      <p className="mt-2 font-mono text-[10px] uppercase tracking-[.16em] opacity-70">
        {label}
      </p>
    </div>
  );
}

export default function Home() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [tag, setTag] = useState(null);
  const [year, setYear] = useState(null);
  const [limit, setLimit] = useState(6);

  useEffect(() => {
    let active = true;
    setLoading(true);
    listPosts()
      .then((data) => {
        if (active) setPosts(data);
      })
      .catch(() => {
        if (active) setError(true);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const stats = useMemo(() => statsFromPosts(posts), [posts]);
  const allTags = useMemo(
    () => Array.from(new Set(posts.flatMap((p) => p.tags ?? []))).sort(),
    [posts]
  );
  const years = useMemo(
    () =>
      Array.from(new Set(posts.map((p) => (postDate(p) || "").slice(0, 4)))),
    [posts]
  );
  const filtered = useMemo(
    () =>
      posts
        .filter(
          (p) =>
            (!tag || p.tags?.includes(tag)) &&
            (!year || (postDate(p) || "").startsWith(year))
        )
        .sort((a, b) => (postDate(b) || "").localeCompare(postDate(a) || "")),
    [posts, tag, year]
  );
  const visiblePosts = filtered.slice(0, limit);

  const spanLabel = stats.firstPostAt
    ? `${formatArchiveDate(stats.firstPostAt)} — ${formatArchiveDate(
        stats.latestPostAt
      )}`
    : "Not yet recorded";

  return (
    <main className="film-grain min-h-[100dvh] overflow-hidden">
      <section className="relative min-h-[720px] bg-foreground text-ink">
        <div
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage:
              "radial-gradient(circle at 80% 35%, #d7fa44 0, transparent 24%), radial-gradient(circle at 8% 88%, rgba(215,250,68,0.12) 0, transparent 32%)",
          }}
        />
        <JourneyHeader dark />
        <div className="relative mx-auto flex max-w-[1400px] flex-col px-5 pb-20 pt-24 md:px-10 md:pt-32">
          <div className="max-w-5xl">
            <p className="reveal font-mono text-[10px] uppercase tracking-[.32em] text-primary">
              Private training log / made public
            </p>
            <h1 className="reveal delay-1 mt-7 max-w-5xl font-display text-[clamp(4.5rem,13vw,12rem)] font-bold leading-[.8] tracking-[-.09em]">
              THE BODY
              <br />
              <span className="text-primary">REMEMBERS.</span>
            </h1>
            <div className="reveal delay-2 mt-12 flex max-w-xl items-start gap-5 border-l border-primary pl-5">
              <span className="font-mono text-[10px] text-primary">01—</span>
              <p className="text-lg leading-relaxed text-ink/70">
                A visual record of showing up. Sets, seasons, misses, and the
                small decisions that eventually become a body.
              </p>
            </div>
          </div>
          <a
            href="#archive"
            className="reveal delay-3 mt-28 flex w-fit items-center gap-3 font-mono text-[10px] uppercase tracking-[.2em] text-primary transition-transform hover:translate-y-1"
          >
            <span className="flex h-10 w-10 items-center justify-center border border-primary">
              <ArrowDown className="h-4 w-4" />
            </span>{" "}
            Enter the archive
          </a>
          <div className="pointer-events-none absolute bottom-10 right-5 hidden max-w-[160px] rotate-90 items-center gap-3 font-mono text-[9px] uppercase tracking-[.2em] text-ink/40 md:flex">
            <span className="h-px w-16 bg-primary/70" /> Full range of motion
          </div>
        </div>
      </section>

      <section className="archive-grid border-b border-foreground/10 bg-background px-5 py-20 md:px-10 md:py-28">
        <div className="mx-auto grid max-w-[1400px] gap-12 md:grid-cols-[1.1fr_.9fr] md:items-end">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[.24em] text-accent">
              The methodology
            </p>
            <h2 className="mt-5 max-w-2xl font-display text-4xl font-bold leading-[.95] tracking-[-.06em] md:text-6xl">
              No before.
              <br />
              No after.
              <br />
              <span className="text-muted-foreground">Only between.</span>
            </h2>
          </div>
          <div className="max-w-md border-t border-foreground/15 pt-5 text-sm leading-relaxed text-muted-foreground">
            <p>
              The internet loves a finish line. This archive is interested in
              the repetition before it — the unremarkable Tuesday, the weight
              that moved, the weight that did not.
            </p>
            <p className="mt-5 font-mono text-[10px] uppercase tracking-[.16em] text-foreground">
              — A record in progress
            </p>
          </div>
        </div>
      </section>

      <section
        id="archive"
        className="mx-auto max-w-[1400px] scroll-mt-8 px-5 py-20 md:px-10 md:py-28"
      >
        <div className="mb-12 flex flex-col justify-between gap-5 border-b border-foreground/15 pb-6 md:flex-row md:items-end">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[.24em] text-accent">
              02 / Field notes
            </p>
            <h2 className="mt-3 font-display text-4xl font-bold tracking-[-.06em] md:text-6xl">
              The archive
            </h2>
          </div>
          <p className="max-w-xs text-sm text-muted-foreground md:text-right">
            Unfiltered entries from the floor. Scroll slowly. Nothing here is a
            highlight reel.
          </p>
        </div>
        {(allTags.length > 0 || years.length > 1) && (
          <div className="mb-10 flex flex-wrap items-center gap-2">
            <FilterChip
              active={!tag && !year}
              onClick={() => {
                setTag(null);
                setYear(null);
                setLimit(6);
              }}
            >
              All
            </FilterChip>
            {years.length > 1 &&
              years.map((y) => (
                <FilterChip
                  key={y}
                  active={year === y}
                  onClick={() => {
                    setYear(year === y ? null : y);
                    setLimit(6);
                  }}
                >
                  {y}
                </FilterChip>
              ))}
            {allTags.map((t) => (
              <FilterChip
                key={t}
                active={tag === t}
                onClick={() => {
                  setTag(tag === t ? null : t);
                  setLimit(6);
                }}
              >
                #{t}
              </FilterChip>
            ))}
          </div>
        )}
        {loading ? (
          <ArchiveSkeletons />
        ) : error ? (
          <div
            className="border border-destructive/30 bg-card p-10 text-center"
            role="alert"
          >
            <p className="font-display text-2xl font-bold">
              The archive is out of focus.
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              We could not load the latest entries.
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="mt-6 border border-foreground/20 px-5 py-3 text-xs font-bold uppercase tracking-[.15em] hover:bg-secondary"
            >
              Try again
            </button>
          </div>
        ) : visiblePosts.length === 0 && posts.length > 0 ? (
          <p className="border border-dashed border-foreground/20 bg-card p-12 text-center text-sm text-muted-foreground">
            No entries match this filter.
          </p>
        ) : visiblePosts.length === 0 ? (
          <div className="border border-dashed border-foreground/20 bg-card p-16 text-center">
            <Camera className="mx-auto h-8 w-8 text-accent" />
            <p className="mt-5 font-display text-2xl font-bold">
              The first set has not been logged.
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              The archive will begin when the work does.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
            {visiblePosts.map((post, index) => (
              <PostCard key={post.id} post={post} index={index} />
            ))}
          </div>
        )}
        {filtered.length > limit && (
          <div className="mt-14 text-center">
            <button
              type="button"
              onClick={() => setLimit((l) => l + 6)}
              className="border border-foreground/20 px-6 py-3 text-xs font-bold uppercase tracking-[.16em] hover:bg-secondary"
            >
              Load more · {filtered.length - limit} older
            </button>
          </div>
        )}
      </section>

      <section className="bg-primary px-5 py-16 text-primary-foreground md:px-10 md:py-20">
        <div className="mx-auto grid max-w-[1400px] gap-12 md:grid-cols-[.8fr_1.2fr] md:items-end">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[.24em] text-primary-foreground/70">
              03 / The record so far
            </p>
            <Quote className="mt-5 h-8 w-8" />
            <p className="mt-5 max-w-sm font-display text-2xl font-bold leading-tight">
              The body keeps a ledger the mirror cannot read.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-px overflow-hidden border border-primary-foreground/25 bg-primary-foreground/25 md:grid-cols-4">
            <Stat icon={Ruler} label="Entries" value={stats.postCount} />
            <Stat icon={Camera} label="Images" value={stats.imageCount} />
            <Stat icon={Film} label="Videos" value={stats.videoCount} />
            <div className="bg-primary p-5">
              <CalendarDays className="h-5 w-5" />
              <p className="mt-4 font-mono text-[11px] uppercase tracking-[.12em] leading-snug">
                {spanLabel}
              </p>
              <p className="mt-2 font-mono text-[10px] uppercase tracking-[.16em] opacity-70">
                Span
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-foreground px-5 py-20 text-ink md:px-10 md:py-28">
        <div className="mx-auto max-w-[1400px]">
          <div className="flex flex-col items-start justify-between gap-8 border-b border-ink/15 pb-10 md:flex-row md:items-end">
            <h2 className="max-w-2xl font-display text-4xl font-bold leading-[.95] tracking-[-.06em] md:text-6xl">
              The work is the point.
              <br />
              <span className="text-primary">The record is the proof.</span>
            </h2>
            <Link
              to="/admin"
              className="flex items-center gap-3 bg-primary px-6 py-3 text-xs font-bold uppercase tracking-[.16em] text-primary-foreground transition-transform hover:-translate-y-0.5"
            >
              Enter the portal <MoveDown className="h-4 w-4" />
            </Link>
          </div>
          <div className="mt-10 flex flex-col justify-between gap-6 font-mono text-[10px] uppercase tracking-[.18em] text-ink/50 md:flex-row">
            <span>© {new Date().getFullYear()} The Sets Archive</span>
            <span>A bodybuilding journey, recorded in progress.</span>
          </div>
        </div>
      </section>
    </main>
  );
}