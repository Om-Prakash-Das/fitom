import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import JourneyHeader from "@/components/JourneyHeader";
import EntryDetails from "@/components/EntryDetails";
import { formatArchiveTime, getPost, postDate } from "@/lib/journey";

export default function Entry() {
  const { id } = useParams();
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setLoading(true);
    getPost(id)
      .then((data) => {
        if (active) setPost(data);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [id]);

  return (
    <main className="film-grain min-h-[100dvh] bg-background">
      <JourneyHeader />
      <div className="mx-auto max-w-4xl px-5 py-12 md:px-10 md:py-16">
        <Link
          to="/#archive"
          className="mb-10 inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Back to the archive
        </Link>

        {loading ? (
          <div className="border border-foreground/10 bg-card">
            <div className="aspect-[4/5] w-full animate-pulse bg-secondary md:aspect-[16/10]" />
          </div>
        ) : !post ? (
          <div className="border border-dashed border-foreground/20 bg-card p-16 text-center">
            <p className="font-display text-3xl font-bold tracking-[-.04em]">
              This entry is not on record.
            </p>
            <p className="mt-3 text-sm text-muted-foreground">
              It may have been removed from the archive.
            </p>
            <Link
              to="/#archive"
              className="mt-8 inline-flex items-center gap-2 border border-foreground/20 px-5 py-3 text-xs font-bold uppercase tracking-[.16em] hover:bg-secondary"
            >
              Return to the archive
            </Link>
          </div>
        ) : (
          <article className="border border-foreground/10 bg-card">
            <div className="flex items-center justify-between border-b border-foreground/10 px-5 py-4 md:px-8">
              <p className="font-mono text-[10px] uppercase tracking-[.24em] text-accent">
                Field notes / Entry
              </p>
              <time
                dateTime={postDate(post)}
                className="font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground"
              >
                {formatArchiveTime(postDate(post))}
              </time>
            </div>
            <div className="bg-foreground">
              {post.media_url &&
                (post.media_type === "video" ? (
                  <video
                    className="max-h-[80vh] w-full object-contain"
                    src={post.media_url}
                    controls
                    aria-label={`Training video from ${formatArchiveTime(
                      postDate(post)
                    )}`}
                  />
                ) : (
                  <img
                    className="max-h-[80vh] w-full object-contain"
                    src={post.media_url}
                    alt={post.caption || "Training archive image"}
                  />
                ))}
            </div>
            <div className="px-6 py-8 md:px-10 md:py-10">
              <p className="max-w-2xl whitespace-pre-line text-xl leading-relaxed md:text-2xl">
                {post.caption}
              </p>
              {post.tags?.length > 0 && (
                <div className="mt-6 flex flex-wrap gap-1.5">
                  {post.tags.map((tag) => (
                    <span
                      key={tag}
                      className="border border-foreground/15 px-2 py-0.5 font-mono text-[10px] uppercase tracking-[.12em] text-muted-foreground"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              )}
              <EntryDetails post={post} />

              <p className="mt-10 border-t border-foreground/10 pt-5 font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">
                — End of entry
              </p>
            </div>
          </article>
        )}
      </div>
    </main>
  );
}