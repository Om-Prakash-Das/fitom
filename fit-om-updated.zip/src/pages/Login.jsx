import { useState } from "react";
import { useNavigate, useSearchParams, Link } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { ArrowUpRight, Lock, Loader2 } from "lucide-react";
import { unlockAdmin } from "@/lib/adminGate";

export default function Login() {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const returnTo = params.get("returnTo") || "/admin";

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    await new Promise((r) => setTimeout(r, 250));
    const ok = unlockAdmin(password.trim());
    setLoading(false);
    if (ok) {
      navigate(returnTo, { replace: true });
    } else {
      setError("Incorrect password");
    }
  };

  return (
    <main className="film-grain relative flex min-h-[100dvh] items-center bg-foreground text-ink">
      <div
        className="pointer-events-none absolute inset-0 opacity-25"
        style={{
          backgroundImage:
            "radial-gradient(circle at 80% 30%, #d7fa44 0, transparent 26%), radial-gradient(circle at 10% 90%, rgba(215,250,68,0.10) 0, transparent 34%)",
        }}
      />
      <div className="relative mx-auto w-full max-w-md px-5 py-16">
        <Link to="/" className="group mb-14 inline-flex items-center gap-3">
          <span className="flex h-9 w-9 items-center justify-center bg-primary text-[11px] font-bold tracking-[-.08em] text-primary-foreground transition-transform group-hover:rotate-6">
            A/01
          </span>
          <span className="font-display text-sm font-bold tracking-[.12em]">
            THE SETS ARCHIVE
          </span>
        </Link>

        <p className="font-mono text-[10px] uppercase tracking-[.32em] text-primary">
          Restricted / owner only
        </p>
        <h1 className="mt-5 font-display text-4xl font-bold leading-[.9] tracking-[-.04em] md:text-5xl">
          Sign in to
          <br />
          <span className="text-primary">keep the record.</span>
        </h1>
        <p className="mt-5 max-w-xs text-sm leading-relaxed text-ink/60">
          Enter the archive password to publish, edit and remove entries.
        </p>

        <form onSubmit={handleSubmit} className="mt-12 space-y-4">
          <div className="space-y-2">
            <label
              htmlFor="password"
              className="font-mono text-[10px] uppercase tracking-[.18em] text-ink/50"
            >
              Password
            </label>
            <div className="relative">
              <Lock
                className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/40"
                aria-hidden="true"
              />
              <Input
                id="password"
                type="password"
                autoComplete="current-password"
                autoFocus
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-12 border-ink/20 bg-ink/5 pl-10 text-ink placeholder:text-ink/30 focus-visible:border-primary focus-visible:ring-0"
                required
              />
            </div>
          </div>

          {error && (
            <p className="border border-destructive/40 bg-destructive/10 px-3 py-2 font-mono text-[11px] uppercase tracking-[.12em] text-destructive">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="flex w-full items-center justify-center gap-2 bg-primary px-6 py-4 text-xs font-bold uppercase tracking-[.18em] text-primary-foreground transition-transform hover:-translate-y-0.5 disabled:translate-y-0 disabled:opacity-60"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" /> Checking…
              </>
            ) : (
              <>
                Enter the portal <ArrowUpRight className="h-4 w-4" />
              </>
            )}
          </button>
        </form>

        <Link
          to="/"
          className="mt-8 inline-block font-mono text-[10px] uppercase tracking-[.18em] text-ink/40 transition-colors hover:text-ink"
        >
          ← Back to the public archive
        </Link>
      </div>
    </main>
  );
}