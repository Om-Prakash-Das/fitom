const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useMemo, useState } from "react";
import { Dumbbell, Plus, Repeat, X } from "lucide-react";
import JourneyHeader from "@/components/JourneyHeader";
import WorkoutCard from "@/components/WorkoutCard";
import WorkoutComposer from "@/components/WorkoutComposer";
import ArchiveSkeletons from "@/components/ArchiveSkeletons";

import { isAdminUnlocked } from "@/lib/adminGate";

// Builds a name → { name, sets, date } lookup of each exercise's most recent
// appearance, used for autocomplete and "last time" quick-fill. `workouts`
// is expected newest-first, so the first match per name wins.
function buildExerciseHistory(workouts) {
  const map = new Map();
  for (const w of workouts) {
    for (const ex of w.exercises || []) {
      const key = ex.name?.trim().toLowerCase();
      if (!key || map.has(key)) continue;
      map.set(key, { name: ex.name.trim(), sets: ex.sets || [], date: w.entry_date });
    }
  }
  return map;
}

function cloneAsTemplate(workout) {
  return {
    focus: workout.focus || "",
    exercises: (workout.exercises || []).map((ex) => ({
      name: ex.name || "",
      group: ex.group || null,
      sets: (ex.sets || []).map((s) => ({ ...s })),
    })),
    notes: "",
  };
}

export default function Workouts() {
  const [workouts, setWorkouts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [composing, setComposing] = useState(false);
  const [editing, setEditing] = useState(null);
  const admin = isAdminUnlocked();

  const exerciseHistory = useMemo(() => buildExerciseHistory(workouts), [workouts]);
  const exerciseNames = useMemo(
    () =>
      Array.from(exerciseHistory.values())
        .map((v) => v.name)
        .sort((a, b) => a.localeCompare(b)),
    [exerciseHistory]
  );

  async function refresh() {
    setLoading(true);
    setError(false);
    try {
      const data = await db.entities.Workout.list("-entry_date", 200);
      setWorkouts(data);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  async function remove(w) {
    if (!window.confirm("Delete this workout?")) return;
    try {
      await db.entities.Workout.delete(w.id);
      await refresh();
    } catch {
      window.alert("Could not delete that workout.");
    }
  }

  function repeatFrom(w) {
    setEditing(cloneAsTemplate(w));
    setComposing(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  const showComposer = admin && (composing || editing);

  return (
    <main className="film-grain min-h-[100dvh] bg-background">
      <JourneyHeader />
      <div className="mx-auto max-w-4xl px-5 py-12 md:px-10 md:py-16">
        <div className="flex items-end justify-between gap-4 border-b border-foreground/15 pb-6">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[.24em] text-accent">
              The training log
            </p>
            <h1 className="mt-3 font-display text-4xl font-bold tracking-[-.06em] md:text-6xl">
              Daily exercises
            </h1>
            <p className="mt-3 max-w-md text-sm text-muted-foreground">
              Sets, weights and reps — written down so the work is accounted for.
            </p>
          </div>
          {admin && !showComposer && (
            <div className="flex shrink-0 items-center gap-2">
              {workouts.length > 0 && (
                <button
                  type="button"
                  onClick={() => repeatFrom(workouts[0])}
                  className="flex items-center gap-2 border border-foreground/20 px-4 py-3 text-xs font-bold uppercase tracking-[.16em] transition-colors hover:bg-secondary"
                  title="Start a new entry from your last workout"
                >
                  <Repeat className="h-4 w-4" /> Repeat last
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  setEditing(null);
                  setComposing(true);
                }}
                className="flex items-center gap-2 bg-primary px-5 py-3 text-xs font-bold uppercase tracking-[.16em] text-primary-foreground transition-transform hover:-translate-y-0.5"
              >
                <Plus className="h-4 w-4" /> Log workout
              </button>
            </div>
          )}
        </div>

        {showComposer && (
          <div className="mt-8 border border-foreground/15 bg-card p-5 md:p-7">
            <div className="mb-5 flex items-center justify-between">
              <h2 className="font-display text-xl font-bold">
                {editing?.id ? "Edit workout" : editing ? "New workout (from repeat)" : "New workout"}
              </h2>
              <button
                type="button"
                onClick={() => {
                  setComposing(false);
                  setEditing(null);
                }}
                className="rounded-full p-2 text-muted-foreground hover:bg-secondary hover:text-foreground"
                aria-label="Dismiss"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <WorkoutComposer
              editing={editing}
              exerciseNames={exerciseNames}
              exerciseHistory={exerciseHistory}
              onDone={() => {
                setComposing(false);
                setEditing(null);
                refresh();
              }}
              onCancel={() => {
                setComposing(false);
                setEditing(null);
              }}
            />
          </div>
        )}

        <div className="mt-10">
          {loading ? (
            <ArchiveSkeletons />
          ) : error ? (
            <div className="border border-destructive/30 bg-card p-10 text-center">
              <p className="font-display text-2xl font-bold">
                Could not load the log.
              </p>
              <button
                type="button"
                onClick={() => window.location.reload()}
                className="mt-6 border border-foreground/20 px-5 py-3 text-xs font-bold uppercase tracking-[.15em] hover:bg-secondary"
              >
                Try again
              </button>
            </div>
          ) : workouts.length === 0 ? (
            <div className="border border-dashed border-foreground/20 bg-card p-16 text-center">
              <Dumbbell className="mx-auto h-8 w-8 text-accent" />
              <p className="mt-5 font-display text-2xl font-bold">
                No workouts logged yet.
              </p>
              <p className="mt-2 text-sm text-muted-foreground">
                The log begins with the first session.
              </p>
            </div>
          ) : (
            <div className="space-y-5">
              {workouts.map((w) => (
                <WorkoutCard
                  key={w.id}
                  workout={w}
                  admin={admin}
                  onEdit={(wk) => {
                    setEditing(wk);
                    setComposing(false);
                    window.scrollTo({ top: 0, behavior: "smooth" });
                  }}
                  onDelete={remove}
                  onRepeat={repeatFrom}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </main>
  );
}