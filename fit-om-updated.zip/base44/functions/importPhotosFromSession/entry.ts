const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';
import exifr from 'npm:exifr';

const PICKER_API = "https://photospicker.googleapis.com/v1";

const CAPTION_PROMPT =
  "You write for 'The Sets Archive', a bodybuilding training log made public. " +
  "Look at this training photo (or a frame from a video). " +
  "Write ONE concise, evocative caption (max 16 words) in the first person, as the athlete logging the session, grounded in what is visible. " +
  "Then give 1-3 short lowercase single-word tags with no '#'. " +
  'Return JSON shaped as {"caption": string, "tags": string[]}';

function formatExposureTime(t) {
  if (t == null) return "";
  if (t >= 1) return `${t}s`;
  return `1/${Math.round(1 / t)}`;
}

// EXIF stores the capture moment as a local wall-clock with no offset. exifr
// parses it into a Date using the runtime timezone, so the UTC components are
// exactly the original wall-clock — format them back as a naive ISO so the
// entry keeps the photo's own date/time, never the import (upload) time.
function exifDateToISO(d) {
  if (!d || !(d instanceof Date) || isNaN(d.getTime())) return null;
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getUTCFullYear()}-${p(d.getUTCMonth() + 1)}-${p(d.getUTCDate())}T${p(d.getUTCHours())}:${p(d.getUTCMinutes())}:${p(d.getUTCSeconds())}`;
}

function buildPhotoMetadata(exif, mediaFile) {
  exif = exif || {};
  const camera = [exif.Make, exif.Model].filter(Boolean).join(" ").trim();

  const exposureParts = [];
  if (exif.FNumber != null) exposureParts.push(`f/${exif.FNumber}`);
  const exp = formatExposureTime(exif.ExposureTime);
  if (exp) exposureParts.push(exp);
  if (exif.FocalLength != null) exposureParts.push(`${exif.FocalLength} mm`);
  const isoRaw = exif.ISO ?? exif.ISOSpeedRatings;
  const iso = Array.isArray(isoRaw) ? isoRaw[0] : isoRaw;
  if (iso != null) exposureParts.push(`ISO${iso}`);

  const width = Number(exif.ImageWidth || exif.ExifImageWidth) || null;
  const height = Number(exif.ImageLength || exif.ExifImageHeight) || null;
  const mp = width && height ? Math.max(1, Math.round((width * height) / 1e6)) : null;
  const resolutionParts = [];
  if (mp) resolutionParts.push(`${mp} MP`);
  if (width && height) resolutionParts.push(`${width} × ${height}`);

  const result = {
    camera,
    exposure: exposureParts.join(" · "),
    filename: mediaFile?.filename || "",
    resolution: resolutionParts.join(" · ")
  };

  if (exif.latitude != null && exif.longitude != null) {
    result.location = { lat: exif.latitude, lon: exif.longitude };
  }
  return result;
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const sessionId = body?.sessionId;
    if (!sessionId) {
      return Response.json({ error: "Missing sessionId" }, { status: 400 });
    }

    const { accessToken } = await db.asServiceRole.connectors.getConnection("google_photos");
    const auth = { "Authorization": `Bearer ${accessToken}` };

    // Confirm the user has finished selecting photos.
    const sessRes = await fetch(`${PICKER_API}/sessions/${sessionId}`, { headers: auth });
    if (!sessRes.ok) {
      const detail = await sessRes.text();
      return Response.json({ error: `Session check failed: ${detail}` }, { status: 502 });
    }
    const sess = await sessRes.json();
    if (!sess.mediaItemsSet) {
      return Response.json({ error: "Photos not selected yet." }, { status: 400 });
    }

    // Gather every selected media item (the list is paginated).
    let pageToken = null;
    const items = [];
    do {
      const url = new URL(`${PICKER_API}/mediaItems`);
      url.searchParams.set("sessionId", sessionId);
      if (pageToken) url.searchParams.set("pageToken", pageToken);
      const r = await fetch(url, { headers: auth });
      if (!r.ok) {
        const detail = await r.text();
        return Response.json({ error: `Could not list media items: ${detail}` }, { status: 502 });
      }
      const data = await r.json();
      items.push(...(data.mediaItems || []));
      pageToken = data.nextPageToken || null;
    } while (pageToken);

    const created = [];
    const skipped = [];

    // Sequential: Google's concurrent-write quota is 1, and LLM/upload calls
    // must each settle before the next to avoid partial / corrupt imports.
    for (const item of items) {
      try {
        const mediaFile = item?.mediaFile;
        const baseUrl = mediaFile?.baseUrl;
        const mimeType = mediaFile?.mimeType || "image/jpeg";
        const filename = mediaFile?.filename || `photo-${item.id || Date.now()}.jpg`;
        // The photo's own capture date, read from its metadata. The Picker API
        // nests mediaMetadata under mediaFile; the Library API puts it at the
        // top level — check both so the date lands regardless of source.
        const metaTime =
          mediaFile?.mediaMetadata?.creationTime ||
          item?.mediaMetadata?.creationTime ||
          null;
        if (!baseUrl) {
          skipped.push({ id: item.id, reason: "no baseUrl" });
          continue;
        }
        const isVideo = mimeType.startsWith("video/");

        // Fetch the original bytes: the file itself carries the full EXIF
        // (camera, exposure, GPS) that the Picker API does not expose.
        const mediaRes = await fetch(baseUrl, { headers: auth });
        if (!mediaRes.ok) {
          skipped.push({ id: item.id, reason: `fetch ${mediaRes.status}` });
          continue;
        }
        const buf = new Uint8Array(await mediaRes.arrayBuffer());
        const file = new File([buf], filename, { type: mimeType });

        let exif = null;
        try {
          exif = await exifr.parse(buf, { tiff: true, ifd0: true, exif: true, gps: true });
        } catch {
          // some files have no parseable EXIF
        }
        // The entry's date is the photo's own capture time from the file's EXIF
        // (never the upload time); the Picker API's creationTime is only a fallback.
        const itemDate = exifDateToISO(exif?.DateTimeOriginal) || metaTime || null;
        const photoMeta = buildPhotoMetadata(exif, mediaFile);

        const uploaded = await db.asServiceRole.integrations.Core.UploadPublicFile({ file });
        const file_url = uploaded.file_url;

        let caption = "";
        let tags = [];
        try {
          const llm = await db.asServiceRole.integrations.Core.InvokeLLM({
            prompt: CAPTION_PROMPT,
            file_urls: [file_url],
            response_json_schema: {
              type: "object",
              properties: {
                caption: { type: "string" },
                tags: { type: "array", items: { type: "string" } }
              },
              required: ["caption", "tags"]
            }
          });
          caption = (llm.caption || "").trim();
          tags = (llm.tags || [])
            .map((t) => String(t).toLowerCase().trim().replace(/^#/, ""))
            .filter(Boolean)
            .slice(0, 5);
        } catch {
          // Caption generation is best-effort; the entry still lands on record.
        }

        const post = await db.asServiceRole.entities.JourneyPost.create({
          media_url: file_url,
          media_type: isVideo ? "video" : "image",
          caption,
          tags,
          photo_metadata: photoMeta,
          ...(itemDate ? { entry_date: itemDate } : {})
        });
        created.push({ id: post.id, caption: post.caption });
      } catch (itemError) {
        skipped.push({ id: item.id, reason: itemError.message });
      }
    }

    return Response.json({
      imported: created.length,
      skipped: skipped.length,
      posts: created
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}