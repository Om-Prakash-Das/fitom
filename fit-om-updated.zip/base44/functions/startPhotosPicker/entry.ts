const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

const PICKER_API = "https://photospicker.googleapis.com/v1";

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const { accessToken } = await db.asServiceRole.connectors.getConnection("google_photos");

    const res = await fetch(`${PICKER_API}/sessions`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({})
    });

    if (!res.ok) {
      const detail = await res.text();
      return Response.json({ error: `Google Photos picker could not start: ${detail}` }, { status: 502 });
    }

    const data = await res.json();
    return Response.json({ pickerUri: data.pickerUri, sessionId: data.id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}